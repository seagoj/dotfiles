// Copyright 2002 by Brian Quinlan <brian@sweetapp.com>
// The License.txt file describes the conditions under which this 
// software may be distributed.

#include "PyLexerModule.h"

#include <BufferAccessor.h>
#include <SciLexer.h>

#include "AutoReleasePool.h"
#include "PyPropSet.h"
#include "PyWordList.h"

static char tokenize_by_style_doc[] = 
"tokenize_by_style('import string', WordList('import...'), PropertSet())\n"
"     => list of tokens\n"
"\n"
"Tokenizes the given string using the provided WordList (or list of WordLists)\n" 
"and the PropertySet. The return value is a list of dictionaries containing\n"
"information about the token. Each dictionary contains the following\n"
"information:\n"
"  style: The lexical style of the token e.g. 11\n"
"  text: The text of the token e.g. 'import'\n"
"  start_index: The index in the buffer where the token begins e.g. 0\n"
"  end_index: The index in the buffer where the token ends e.g. 5\n"
"  start_column: The column position (0-based) where the token begins e.g. 0\n"
"  end_column: The column position (0-based) where the token ends e.g. 5\n"
"  start_line: The line position (0-based) where the token begins e.g. 0\n"
"  end_line: The line position (0-based) where the token ends e.g. 0\n"
"\n"
"Optionally, you may also pass a callback function as the last argument.\n"
"The callback function will receive the token information by keyword\n"
"arguments e.g.:\n"
"def my_callback(style, text, start_index, ..., **other_args):\n"
"    pass\n";

static char get_number_of_wordlists_doc[] = 
"get_number_of_wordlists() => 2\n"
"\n"
"Returns the number of WordLists that the lexer requires i.e. for\n"
"for tokenize_by_style.\n"
"\n"
"Raises a ValueError if no WordList information is available.";
    
static char get_wordlist_descriptions_doc[] = 
"get_wordlist_descriptions() => (\"Python keywords\")\n"
"\n"
"Returns a sequence containing a description for each WordList that the\n"
"lexer requires i.e for tokenize_by_style.\n"
"\n"
"Raises a ValueError if no WordList information is available.";

static WordList **
getWordList(PyObject * pyWordLists, const LexerModule * lexer, AutoReleasePool & pool);

PyObject*
PyLexerModule_new(const LexerModule * lexer)
{
    PyLexerModule*  pyLexerModule;

    pyLexerModule = PyObject_New(PyLexerModule, &PyLexerModuleType);
    pyLexerModule->lexer = lexer;

    return (PyObject*) pyLexerModule;
}

static void
PyLexerModule_dealloc(PyLexerModule* self)
{
    PyObject_Del(self);
}

static int
numWordLists(const LexerModule * lexer)
{
	// If your favorite lexer doesn't support
	// GetNumWordLists() then you can add it here
    if (lexer->GetNumWordLists() > 0)
        return lexer->GetNumWordLists();

    switch (lexer->GetLanguage()) {
        case SCLEX_NULL: return 0;
    }
    return -1;
}

#if PYTHON_API_VERSION<1011
// This function was added in Python 2.2

#define PyObject_Call(func,arg, kw) \
        PyEval_CallObjectWithKeywords(func, arg, kw)
#endif

static PyObject *
PyLexerModule_tokenize_by_style(PyLexerModule* self, PyObject * args)
{
    PyObject * pyWordLists = NULL;
    WordList ** wordLists = NULL;
    PropSet * propset = NULL;
    PyObject * pyPropSet = NULL;
    PyObject * pyTokenList = NULL;
    PyObject * pyToken = NULL;
    PyObject * pyCallback = NULL;
    PyObject * pyEmptyTuple = NULL;
    PyObject * pyCallbackResult = NULL;
    char * style = NULL;
    char * buf = NULL;
    AutoReleasePool pool;
    int bufSize;
    int i;
    int startIndex;
    int startLine;
    int line;
    int startCol;
    int col;

    if (!PyArg_ParseTuple(args, "s#OO|O", &buf, &bufSize, &pyWordLists, &pyPropSet, &pyCallback))
        return NULL;

    if (!PyPropSet_Check(pyPropSet)) {
        PyErr_Format(PyExc_TypeError, "expected PropertySet, %.200s found",
            pyPropSet->ob_type->tp_name);
        return NULL;
    }

    if ((pyCallback != NULL) && !PyCallable_Check(pyCallback)) {
        PyErr_Format(PyExc_TypeError, "expected callable object, %.200s found",
            pyCallback->ob_type->tp_name);
        return NULL;        
    }

    wordLists = getWordList(pyWordLists, self->lexer, pool);
    if (wordLists == NULL)
       return NULL;

    style = new char[bufSize];
    propset = PyPropSet_GET_PROPSET(pyPropSet);
    BufferAccessor bufAccessor(buf, bufSize, style, *propset);

    Py_BEGIN_ALLOW_THREADS
        self->lexer->Lex(0, bufSize, 0, wordLists, bufAccessor);
    Py_END_ALLOW_THREADS

    if (pyCallback == NULL) {
        pyTokenList = PyList_New(0);
        if (pyTokenList == NULL)
            goto onError;
    } else {
        pyEmptyTuple = PyTuple_New(0);
        if (pyEmptyTuple == NULL)
            goto onError;
    }
    
    for (i = startIndex = startLine = startCol = 0; i <= bufSize; ++i) {
        if ((i == bufSize) || ((i != 0) && (style[i] != style[i-1]))) {
            line = bufAccessor.GetLine(i-1);
            col = bufAccessor.GetColumn(i-1);

            pyToken = Py_BuildValue("{s:i,s:s#,s:i,s:i,s:i,s:i,s:i,s:i}", 
                "style", style[i - 1], 
                "text", &(buf[startIndex]), i - startIndex,
                "start_index", startIndex, 
                "end_index", i - 1, 
                "start_line", startLine, 
                "start_column", startCol,
                "end_line", line, 
                "end_column", col);

            if (pyToken == NULL)
                goto onError;

            if (pyCallback == NULL) {
                if (PyList_Append(pyTokenList, pyToken) == -1)
                    goto onError;
            } else {
                pyCallbackResult = PyObject_Call(pyCallback, pyEmptyTuple, pyToken);
                if (pyCallbackResult == NULL)
                    goto onError;
                Py_DECREF(pyCallbackResult);
            }


            Py_DECREF(pyToken);

            if (i != bufSize) {
                startIndex = i;
                startLine = bufAccessor.GetLine(i);
                startCol = bufAccessor.GetColumn(i);
            }
        }
    }

    Py_XDECREF(pyEmptyTuple);

    delete[] wordLists;
    delete [] style;

    if (pyCallback == NULL)
        return pyTokenList;
    else
        return Py_BuildValue("");

onError:
    Py_XDECREF(pyTokenList);
    Py_XDECREF(pyToken);
    Py_XDECREF(pyEmptyTuple);
    delete[] wordLists;
    delete [] style;

    return NULL;
}

static WordList **
getWordList(PyObject * pyWordLists, const LexerModule * lexer, AutoReleasePool & pool)
{
    WordList ** wordLists = NULL;
    PyObject * pyWordList = NULL;
    int size;

    if (numWordLists(lexer) == -1) {
        PyErr_Format(PyExc_ValueError, "cannot determined WordList requirements for lexer");
        return NULL;
    }

    if (PyWordList_Check(pyWordLists)) {
        if (numWordLists(lexer) != 1) {
            PyErr_Format(PyExc_TypeError,
                "eELEASdule  }
        }
        3et, 4, p0hcts, &pyPropSet, &pyCallback))
 CE_V_OPERATOR = 10
SCE_V_IDENTIFIER = 11
SCE_V_STRINGEOL = 12
SCE_V_USER = 19

SCE_KASCE_V_IDENTIFIER = 11
SCE_V_ydCE_V_ydCdule, &PynNAMBUIER = 11
SCE_V_ydC[0]     (lexer) !buf,
SCLIST{
          ck(pyWordLists)) {

static WordLi}r_Format(PyExc_Sthe\n"!= 1) {
            PyErr_Forma %.200s found",
            pyCallback-Callback))
 CE_V_OPme);
        return NULL;   E_V_STRINGEOL = 12, & pool)
{ if ((pyCallback != NULL) && !PyCallable_Check(pyCallbackyErr     Sthe\n"!  st{
          ck(pyWo(PyEyErr  determined WordLists)) {
        if (numWordLisyErr    E_V_STRINGEOL = 12
 PyErr_Forma %.200s found",
            pyCallback- the\n"
ack))
 CE_V_OPER))ropertyS)return NULL;   E_V_STRINGEOL = 12, yErr= NULL) && !PyCallable_Check(pyCallbackSCE_V_ydCE_V_ydCdule, &PynNAs    Buf<= bufSize; line| ((i != PyErr_le[i] != style[i-s(lexer) == -  Sthe\n"!_XDItemNULL)
       ionError;
    }!ts(lexer) != 1) {
        )        "eELEASdule  }
        }
        3etpyCallback-Callback
 CE_V_OPme);
        return NULL;   le[i-s(lexer) = if ((pyCallback != NULL) && !  node = node->next);
            }

} Node * save CE_V_ydC[i]     (lexer) !buf,
SCLIST{
        tartIndex = i;t * .de()
        tart

} Node * sts)) {

static Wo(pyToken);
    NULL;
}

static WordLidelete [] sty        tart

ect * pyWordLists, const Le* self, PyObject * args)mber of WordLists that t pyWordLists = NULL;
    WordList ** wordList linnW
static Wo(p, &pyWordLists, &pyPropSet, &pyCa"ropSet)) {
        PyErr_Fo __init  PropSet * E_V_STRINGEOL
    Py_EN ck(pyWo(PyEt  PropSet <bufA{XDECREF(pyTokenList requirements for lexer");
        return NULL;
    }

    if (PyWordList_Check(pyWoll(pyCallback, pyETokenList);
    Py_XDiV_In          ck(pyWo}Lists, const Le* self, PyObject * args)mber"
"Returns a sequence pyWordLists = NULL;
    WordList ** wordLists = NULL;
  Ds a sequencropSe Wo(p, &pylinn_V_STRINGEO buf
    Py_END_{
        case SCLEormat(PyExc_TypeErro <bufA{XDECREF(pyTokenList requirements for lexer");
        return NULL;
    }

    if (PyWordList_Check(pyWolexerModuleDs a sequencropSe           gotoExc_TypeErroSCLEormat(PyleDs a sequencropSe  return Py_BuildValue("")yPropSet_GET_Size; line| ((i != PExc_TypeErro_le[i] != style[i-s = NULL;
 YAMLHandler._  S\n" _FromS\n" (f
    Py_END_{
_TypeErrDs a sequenpyEtartIndex = i;t(Py YAMLHandler., pyToken) == -1)
                Ds a sequencropSe)     }

} Node * save        Suf,ITEM   Ds a sequencropSe  i,
 YAMLHandletart

} Node * sts)) {  Ds a sequencropSe Wo} ts, const Le*MethodDefyObject_New(Py_methodss\")\n"n) == -{), PropertSet())\nV_IntsCF(func,a) bject * args)
{
    PyObject , METH = 0ARGS,string', WordList('imp},) == -{)mber of WordLists that V_IntsCF(func,a) bject * args)mber of WordLists that , METH = 0ARGS,sts() => 2\n"
"\n"
"Return},) == -{)mber"
"Returns a sequencV_IntsCF(func,a) bject * args)mber"
"Returns a sequenc, METH = 0ARGS,sts()ns() => (\"Python keyword},) == -{ pyTo, pyToo}Lisrr_Fo _const Le* self, PyObject * args)mbeattre pyWordLists  *NULL;ufSizeck !=n"n) == -TokenList)FindMethod(Object_New(Py_methods, ReleasePool) NULL;ck != NUsts, const Le* self, P yObject * args)repre pyWordLists  *NULL=n"n) in Python 2.2

#defi>e PyOb== -//_  S\n" _Fromuiremerg, kw) \
        PyEval_CamWordLisy
    Py_END_        Nk !=A{XDECREF(pyTokenListS\n" _Fromuireme("<%s->tp_na_Size\"%s\" Langp>V_IDENTIFIER = 11
SCCCCCCCCCCCCCCCCCCCCCy
    f ((pyCallback !, y
    Py_END_        Nk !, y
  eck(pyWoll(pyCallback, pyETokenListS\n" _Fromuireme("<%s->tp_na_Langp>V_DENTIFIER = 11
SCCCCCCCCCCCCCCCCCCCCCy
    f ((pyCallback !, y
  tart

} N# Py_XD int bufSizt_in1024];CamWordLisy
    Py_END_        Nk !=A{XDECREF(pyspn" tfHREADS"<%s->tp_na_Size\"%s\" Langp>V_IDENTIFIER = 11
SCy
    f ((pyCallback !, y
    Py_END_        Nk !, y
  eck(pyWoll(pyCallback, pyEspn" tfHREADS"<%s->tp_na_Langp>V_DENTIFIER = 11
SCy
    f ((pyCallback !, y
  tart

} N) == -TokenListS\n" _FromS\n" (REAtarttyle(PyL}er)
{     self, 
    return (PyO")\s(const LexerModOMME_INIT(turn Py_Bui0_DENTIF"    return V_DENTIFyErrofe pyWordLists s YAMLHa0_DENTIFy YA
prior) bject * args)
}

,1
SC/*lba
}

*/YAMLHa0_                                      /*lbapn" t*/YAMLHa(mbeattrle_t) bject * args)mbeattr,    /*lbambeattr*/YAMLHa0_                                      /*lbasbeattr*/YAMLHa0_                                      /*lbacompare*/YAMLHa(reprle_t) bject * args)repr,          /*lbarepr*/YAMLHa0_                                      /*lbaas) => 2\*/YAMLHa0_                                      /*lbaas) the\n"*/YAMLHa0_                                      /*lbaas)mapp" */YAMLHa0_                                      /*lbahash */YAMLHa0_                                      /*lbac}
*/YAMLHa0_                                      /*lbastr */YAsrr_Fo _ PyObj 000bject * args) add(