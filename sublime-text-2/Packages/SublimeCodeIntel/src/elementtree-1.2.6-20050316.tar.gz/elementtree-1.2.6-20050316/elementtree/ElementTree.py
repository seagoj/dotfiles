#
# ElementTree
# $Id: ElementTree.py 2326 2005-03-17 07:45:21Z fredrik $
#
# light-weight XML support for Python 1.5.2 and later.
#
# history:
# 2001-10-20 fl   created (from various sources)
# 2001-11-01 fl   return root from parse method
# 2002-02-16 fl   sort attributes in lexical order
# 2002-04-06 fl   TreeBuilder refactoring, added PythonDoc markup
# 2002-05-01 fl   finished TreeBuilder refactoring
# 2002-07-14 fl   added basic namespace support to ElementTree.write
# 2002-07-25 fl   added QName attribute support
# 2002-10-20 fl   fixed encoding in write
# 2002-11-24 fl   changed default encoding to ascii; fixed attribute encoding
# 2002-11-27 fl   accept file objects or file names for parse/write
# 2002-12-04 fl   moved XMLTreeBuilder back to this module
# 2003-01-11 fl   fixed entity encoding glitch for us-ascii
# 2003-02-13 fl   added XML literal factory
# 2003-02-21 fl   added ProcessingInstruction/PI factory
# 2003-05-11 fl   added tostring/fromstring helpers
# 2003-05-26 fl   added ElementPath support
# 2003-07-05 fl   added makeelement factory method
# 2003-07-28 fl   added more well-known namespace prefixes
# 2003-08-15 fl   fixed typo in ElementTree.findtext (Thomas Dartsch)
# 2003-09-04 fl   fall back on emulator if ElementPath is not installed
# 2003-10-31 fl   markup updates
# 2003-11-15 fl   fixed nested namespace bug
# 2004-03-28 fl   added XMLID helper
# 2004-06-02 fl   added default support to findtext
# 2004-06-08 fl   fixed encoding of non-ascii element/attribute names
# 2004-08-23 fl   take advantage of post-2.1 expat features
# 2005-02-01 fl   added iterparse implementation
# 2005-03-02 fl   fixed iterparse support for pre-2.2 versions
#
# Copyright (c) 1999-2005 by Fredrik Lundh.  All rights reserved.
#
# fredrik@pythonware.com
# http://www.pythonware.com
#
# --------------------------------------------------------------------
# The ElementTree toolkit is
#
# Copyright (c) 1999-2005 by Fredrik Lundh
#
# By obtaining, using, and/or copying this software and/or its
# associated documentation, you agree that you have read, understood,
# and will comply with the following terms and conditions:
#
# Permission to use, copy, modify, and distribute this software and
# its associated documentation for any purpose and without fee is
# hereby granted, provided that the above copyright notice appears in
# all copies, and that both that copyright notice and this permission
# notice appear in supporting documentation, and that the name of
# Secret Labs AB or the author not be used in advertising or publicity
# pertaining to distribution of the software without specific, written
# prior permission.
#
# SECRET LABS AB AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD
# TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANT-
# ABILITY AND FITNESS.  IN NO EVENT SHALL SECRET LABS AB OR THE AUTHOR
# BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY
# DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
# WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
# ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
# OF THIS SOFTWARE.
# --------------------------------------------------------------------

__all__ = [
    # public symbols
    "Comment",
    "dump",
    "Element", "ElementTree",
    "fromstring",
    "iselement", "iterparse",
    "parse",
    "PI", "ProcessingInstruction",
    "QName",
    "SubElement",
    "tostring",
    "TreeBuilder",
    "VERSION", "XML",
    "XMLTreeBuilder",
    ]

##
# The <b>Element</b> type is a flexible container object, designed to
# store hierarchical data structures in memory. The type can be
# described as a cross between a list and a dictionary.
# <p>
# Each element has a number of properties associated with it:
# <ul>
# <li>a <i>tag</i>. This is a string identifying what kind of data
# this element represents (the element type, in other words).</li>
# <li>a number of <i>attributes</i>, stored in a Python dictionary.</li>
# <li>a <i>text</i> string.</li>
# <li>an optional <i>tail</i> string.</li>
# <li>a number of <i>child elements</i>, stored in a Python sequence</li>
# </ul>
#
# To create an element instance, use the {@link #Element} or {@link
# #SubElement} factory functions.
# <p>
# The {@link #ElementTree} class can be used to wrap an element
# structure, and convert it from and to XML.
##

import string, sys, re

class _SimpleElementPath:
    # emulate pre-1.2 find/findtext/findall behaviour
    def find(self, element, tag):
        for elem in element:
            if elem.tag == tag:
                return elem
        return None
    def findtext(self, element, tag, default=None):
        for elem in element:
            if elem.tag == tag:
                return elem.text or ""
        return default
    def findall(self, element, tag):
        if tag[:3] == ".//":
            return element.getiterator(tag[3:])
        result = []
        for elem in element:
            if elem.tag == tag:
                result.append(elem)
        return result

try:
    import ElementPath
except ImportError:
    # FIXME: issue warning in this case?
    ElementPath = _SimpleElementPath()

# TODO: add support for custom namespace resolvers/default namespaces
# TODO: add improved support for incremental parsing

VERSION = "1.2.6"

##
# Internal element class.  This class defines the Element interface,
# and provides a reference implementation of this interface.
# <p>
# You should not create instances of this class directly.  Use the
# appropriate factory functions instead, such as {@link #Element}
# and {@link #SubElement}.
#
# @see Element
# @see SubElement
# @see Comment
# @see ProcessingInstruction

class _ElementInterface:
    # <tag attrib>text<child/>...</tag>tail

    ##
    # (Attribute) Element tag.

    tag = None

    ##
    # (Attribute) Element attribute dictionary.  Where possible, use
    # {@link #_ElementInterface.get},
    # {@link #_ElementInterface.set},
    # {@link #_ElementInterface.keys}, and
    # {@link #_ElementInterface.items} to access
    # element attributes.

    attrib = None

    ##
    # (Attribute) Text before first subelement.  This is either a
    # string or the value None, if there was no text.

    text = None

    ##
    # (Attribute) Text after this element's end tag, but before the
    # next sibling element's start tag.  This is either a string or
    # the value None, if there was no text.

    tail = None # text after end tag, if any

    def __init__(self, tag, attrib):
        self.tag = tag
        self.attrib = attrib
        self._children = []

    def __repr__(self):
        return "<Element %s at %x>" % (self.tag, id(self))

    ##
    # Creates a new element object of the same type as this element.
    #
    # @param tag Element tag.
    # @param attrib Element attributes, given as a dictionary.
    # @return A new element instance.

    def makeelement(self, tag, attrib):
        return Element(tag, attrib)

    ##
    # Returns the number of subelements.
    #
    # @return The number of subelements.

    def __len__(self):
        return len(self._children)

    ##
    # Returns the given subelement.
    #
    # @param index What subelement to return.
    # @return The given subelement.
    # @exception IndexError If the given element does not exist.

    def __getitem__(self, index):
        return self._children[index]

    ##
    # Replaces the given subelement.
    #
    # @param index What subelement to replace.
    # @param element The new element value.
    # @exception IndexError If the given element does not exist.
    # @exception AssertionError If element is not a valid object.

    def __setitem__(self, index, element):
        assert iselement(element)
        self._children[index] = element

    ##
    # Deletes the given subelement.
    #
    # @param index What subelement to delete.
    # @exception IndexError If the given element does not exist.

    def __delitem__(self, index):
        del self._children[index]

    ##
    # Returns a list containing subelements in the given range.
    #
    # @param start The first subelement to return.
    # @param stop The first subelement that shouldn't be returned.
    # @return A sequence object containing subelements.

    def __getslice__(self, start, stop):
        return self._children[start:stop]

    ##
    # Replaces a number of subelements with elements from a sequence.
    #
    # @param start The first subelement to replace.
    # @param stop The first subelement that shouldn't be replaced.
    # @param elements A sequence object with zero or more elements.
    # @exception AssertionError If a sequence member is not a valid object.

    def __setslice__(self, start, stop, elements):
        for element in elements:
            assert iselement(element)
        self._children[start:stop] = list(elements)

    ##
    # Deletes a number of subelements.
    #
    # @param start The first subelement to delete.
    # @param stop The first subelement to leave in there.

    def __delslice__(self, start, stop):
        del self._children[start:stop]

    ##
    # Adds a subelement to the end of this element.
    #
    # @param element The element to add.
    # @exception AssertionError If a sequence member is not a valid object.

    def append(self, element):
        assert iselement(element)
        self._children.append(element)

    ##
    # Inserts a subelement at the given position in this element.
    #
    # @param index Where to insert the new subelement.
    # @exception AssertionError If the element is not a valid object.

    def insert(self, index, element):
        assert iselement(element)
        self._children.insert(index, element)

    ##
    # Removes a matching subelement.  Unlike the <b>find</b> methods,
    # this method compares elements based on identity, not on tag
    # value or contents.
    #
    # @param element What element to remove.
    # @exception ValueError If a matching element could not be found.
    # @exception AssertionError If the element is not a valid object.

    def remove(self, element):
        assert iselement(element)
        self._children.remove(element)

    ##
    # Returns all subelements.  The elements are returned in document
    # order.
    #
    # @return A list of subelements.
    # @defreturn list of Element instances

    def getchildren(self):
        return self._children

    ##
    # Finds the first matching subelement, by tag name or path.
    #
    # @param path What element to look for.
    # @return The first matching element, or None if no element was found.
    # @defreturn Element or None

    def find(self, path):
        return ElementPath.find(self, path)

    ##
    # Finds text for the first matching subelement, by tag name or path.
    #
    # @param path What element to look for.
    # @param default What to return if the element was not found.
    # @return The text content of the first matching element, or the
    #     default value no element was found.  Note that if the element
    #     has is found, but has no text content, this method returns an
    #     empty string.
    # @defreturn string

    def findtext(self, path, default=None):
        return ElementPath.findtext(self, path, default)

    ##
    # Finds all matching subelements, by tag name or path.
    #
    # @param path What element to look for.
    # @return A list or iterator containing all matching elements,
    #    in document order.
    # @defreturn list of Element instances

    def findall(self, path):
        return ElementPath.findall(self, path)

    ##
    # Resets an element.  This function removes all subelements, clears
    # all attributes, and sets the text and tail attributes to None.

    def clear(self):
        self.attrib.clear()
        self._children = []
        self.text = self.tail = None

    ##
    # Gets an element attribute.
    #
    # @param key What attribute to look for.
    # @param default What to return if the attribute was not found.
    # @return The attribute value, or the default value, if the
    #     attribute was not found.
    # @defreturn string or None

    def get(self, key, default=None):
        return self.attrib.get(key, default)

    ##
    # Sets an element attribute.
    #
    # @param key What attribute to set.
    # @param value The attribute value.

    def set(self, key, value):
        self.attrib[key] = value

    ##
    # Gets a list of attribute names.  The names are returned in an
    # arbitrary order (just like for an ordinary Python dictionary).
    #
    # @return A list of element attribute names.
    # @defreturn list of strings

    def keys(self):
        return self.attrib.keys()

    ##
    # Gets element attributes, as a sequence.  The attributes are
    # returned in an arbitrary order.
    #
    # @return A list of (name, value) tuples for all attributes.
    # @defreturn list of (string, string) tuples

    def items(self):
        return self.attrib.items()

    ##
    # Creates a tree iterator.  The iterator loops over this element
    # and all subelements, in document order, and returns all elements
    # with a matching tag.
    # <p>
    # If the tree structure is modified during iteration, the result
    # is undefined.
    #
    # @param tag What tags to look for (default is to return all elements).
    # @return A list or iterator containing all the matching elements.
    # @defreturn list or iterator

    def getiterator(self, tag=None):
        nodes = []
        if tag == "*":
            tag = None
        if tag is None or self.tag == tag:
            nodes.append(self)
        for node in self._children:
            nodes.extend(node.getiterator(tag))
        return nodes

# compatibility
_Element = _ElementInterface

##
# Element factory.  This function returns an object implementing the
# standard Element interface.  The exact class or type of that object
# is implementation dependent, but it will always be compatible with
# the {@link #_ElementInterface} class in this module.
# <p>
# The element name, attribute names, and attribute values can be
# either 8-bit ASCII strings or Unicode strings.
#
# @param tag The element name.
# @param attrib An optional dictionary, containing element attributes.
# @param **extra Additional attributes, given as keyword arguments.
# @return An element instance.
# @defreturn Element

def Element(tag, attrib={}, **extra):
    attrib = attrib.copy()
    attrib.update(extra)
    return _ElementInterface(tag, attrib)

##
# Subelement factory.  This function creates an element instance, and
# appends it to an existing element.
# <p>
# The element name, attribute names, and attribute values can be
# either 8-bit ASCII strings or Unicode strings.
#
# @param parent The parent element.
# @param tag The subelement name.
# @param attrib An optional dictionary, containing element attributes.
# @param **extra Additional attributes, given as keyword arguments.
# @return An element instance.
# @defreturn Element

def SubElement(parent, tag, attrib={}, **extra):
    attrib = attrib.copy()
    attrib.update(extra)
    element = parent.makeelement(tag, attrib)
    parent.append(element)
    return element

##
# Comment element factory.  This factory function creates a special
# element that will be serialized as an XML comment.
# <p>
# The comment string can be either an 8-bit ASCII string or a Unicode
# string.
#
# @param text A string containing the comment string.
# @return An element instance, representing a comment.
# @defreturn Element

def Comment(text=None):
    element = Element(Comment)
    element.text = text
    return element

##
# PI element factory.  This factory function creates a special element
# that will be serialized as an XML processing instruction.
#
# @param target A string containing the PI target.
# @param text A string containing the PI contents, if any.
# @return An element instance, representing a PI.
# @defreturn Element

def ProcessingInstruction(target, text=None):
    element = Element(ProcessingInstruction)
    element.text = target
    if text:
        element.text = element.text + " " + text
    return element

PI = ProcessingInstruction

##
# QName wrapper.  This can be used to wrap a QName attribute value, in
# order to get proper namespace handling on output.
#
# @param text A string containing the QName value, in the form {uri}local,
#     or, if the tag argument is given, the URI part of a QName.
# @param tag Optional tag.  If given, the first argument is interpreted as
#     an URI, and this argument is interpreted as a local name.
# @return An opaque object, representing the QName.

class QName:
    def __init__(self, text_or_uri, tag=None):
        if tag:
            text_or_uri = "{%s}%s" % (text_or_uri, tag)
        self.text = text_or_uri
    def __str__(self):
        return self.text
    def __hash__(self):
        return hash(self.text)
    def __cmp__(self, other):
        if isinstance(other, QName):
            return cmp(self.text, other.text)
        return cmp(self.text, other)

##
# ElementTree wrapper class.  This class represents an entire element
# hierarchy, and adds somentaclass.=ocaLhe attribute value, or the defarget8element.
# @pa
        if isinstance(other, QName):
            return cmp(self.text, othereturn
lement could not  If given,  to {@link defant(ent coe
# 2 If givene
# 2 {uriren:
it__(interpreted as ncludeErcumenclasfreI targestribute ment

desertionErparaeleme      te adds somen:attrib
        self._chil {@link=_init_elem    self.text = ns all ent(elementildren:
subelements.  The elements are re,  tome wrappe #a localget("encodingif_elem def find(self, ele        daturned in an arbitrar is t  to {@linkt elemehing is turn list of (string, xtra):
    attrib = th.find(self, path)

            tag data.nt, by tag name or path.
   datant to replace.
    # @param t  to {@linkt elemehing is  attribdiscoths(self, key,       sment

desertio    # ructure   # @paitestribute  IOErrirst subeleme@link #stribche E matching element could not  xtra):
    attrib = ttrib
    sg data.nt, 

    ##
    # Returns all subelements.  The elements are re,  tome wrappent to replace.
Lose ParsentIrenceparaIf the trasso<i>attributes<g is turn list of (, stop)t shouAle
# 2003-odule
# 2lf._chiling all matchind usattributes, gind usar fails, it ca    preted as n, key, defext, othe names, designed to
#}gind usarsn oute was not found.
   If the tr,  to {@link dth.find(self, path)

            t      lement  functiind us    self.text = tex       ext (  functi"miss"  def find(self,t shou
    el  functi"mb  self.tag = s    ind us:      node = loade]+)| designed to
#()       index = index + 1
     directiault_lo)
   32768e = {}

##
# (InternadirePath
except Importb)
 k      node = loade].feed(dire elements are re,  tomeloade].nt.
# @paramname or path.
   datant to replace.
ents, in document ordert element,  to {@link  and returns all eleement innts
.
    # @def be
# eit  # ru path):
        return Ereturn A list or iterator containing all the matching elements.
    # @defrist of (string, xtnt order,dth.find(self, pat"*":
            tag = None
        if tag is None or sns all are re,  to_cache.cleaparamname or path.
   datae

##
# Element f @param path What element to lotoplevece implemestrib SubEl    # is unSam testag data.th, def      element, or None if no element was found.
    # @defreturn Element or None

    def find(self, path):
        return ElementPath.find(self, path)

    ##
    # Finds text for the first matching ns all are re,  to_cache.cleaparamname       [:1   while tokens:
     ror:
  ".an brator(tag))
  or path.
   datae, def      @param path What element was founWhat element to lotoplevece implemestrib SubEntents.
is inSam testag data.th, deor pa      element, or None if no elementtoplevece impleme @return The text content of the first matching element, or the
    #     default value no element was found.  Note that if the element
    #     has is found, but has no text content, this method returns an
    #     empty string.
    # @defreturn string

    def findtext(self, path, default=None):
        return ElementPath.findtext(self, path, default)

    ##
    # Finds all matching suns all are re,  to_cache.cleaparamname       [:1   while tokens:
     ror:
  ".an brator(tag))
  or path.
   datae, deor pa        # @param path What element to ltoplevece implemsestribute  IOErl    # is unSam testag data.th, dents,      element, or None if no element was found.
    # @defreturn Elemen # @defreturn list of Element instances

    def findall(self, path):
        return ElementPath.findall(self, path)

    ##
    # Resets an element.  This functins all are re,  to_cache.cleaparamname       [:1   while tokens:
     ror:
  ".an brator(tag))
  or path.
   datae, dents,     am path What elWxed lement was foun and/omoryi    asereturlement, or None if e
# 2Ale
# 2003-,eturn e
# 2lf._ch    erge eleES Wturn Elemente mode is "xml", this
# 
#    e is "xml" the matchinUS-strin)= ttrib
   ixed  elemenyi    ree.parse"ingInstr"This functins all are re,  to_cache.cleaparamname          ext (yi    "ixed "  def find(selfoot()
    elyi    "ib  self.tag = s    
##
# Expand XInclude  is "xml"  "ingInstr"           "xi:is "xml"h seutf-8"uctur:is "xml"h seungInstr" def find(selfoot(ing in("<?xmledrik@py='1.0' ree.parse'%s'?>\n i + am elem Root nts are reng in(yi    are re,  t  ree.pars, {}) ttrib
    ixed  elemenyi    get(  ree.pars, ##
# Inter  def find(# ixed epara2004-lelement)
       t:
     or node in self._chfactory def find(selfoot(ing in("<!-- sam--e as _escope_cdire.text ot
# h am elem             "xielf._chte value, in
# order  def find(selfoot(ing in("<?%s?e as _escope_cdire.text ot
# h am elem                                     t:
  
    # a            xmlns_        []e, ifw ##
# Inter be
# eitsc   dex + 1
            except IndexEreturn cmp(selftory.other), xpath[:1   whi{"
                    new , xmlnse.cloxew ftory.##
# Inter ew[1:])
                xmlns: xmlns_              mlns)            if isinsTypeeset:
                 _stanc_           re_oader(ath_descendant_oroot(ing in("<an b_ am elftory. am elem           exEretur     if emlns_         except IndexEre     thon()
   2-05-01 fl    == path:
          k, v be
         except IndexErtance(tag, type("")):
       exEreturn cmp(selfky.other), xpk[:1   whi{"
                    nnnnnnnnnk, xmlnse.cloxew fky.##
# Inter ew[1:])
                        xmlns: xmlns_              mlns)            i       if isinsTypeeset:
                         _stanc_           re_oader(k)   except IndexErtance(tag, type("")):
       exEreturn cmp(selfv, other)

##
# Elementttttttttttttttttv, xmlnse.cloxew fvy.##
# Inter ew[1:])
                        xmlns: xmlns_              mlns)            i       if isinsTypeeset:
                         _stanc_           re_oader(v)            i       ioot(ing in(" sa=\"%s\"  ret_ am elfky. am elem ,ew[1:])
                                        _escope_ext A fvy. am elem  )  == path:
          k, v be
emlns_         except IndexEr   ioot(ing in(" sa=\"%s\"  ret_ am elfky. am elem ,ew[1:])
                                        _escope_ext A fvy. am elem  )  == path:
    "cannag[:3] ==ndexcache                 ifot(ing in(">"                    "cann.essingInstruct           ifot(ing in(_escope_cdire.text ot
# h am elem                   retur              set.append(node)are reng in(yi    n  ree.pars, ##
# Inter                 ifot(ing in("</an b_ am elftory. am elem his >"                                   ifot(ing in(" />"                  k, v be
emlns_         except IndexEremen##
# Inter[v]
          "cann.e[i] = node
      fot(ing in(_escope_cdire.text o[i] h am elem   tTree toolkit is
#
# Copyright (c) 1999-2005 by Fredrik Lundh
#
# By obtaient factat willhecks Proce2lf._ch otice ap200be       se
    # @param urn
lement coextra):
    attrib = att Elemen ## o   def _ise the
#name, attribuparam urnlementPath.ffl  ouctiosubelements.  The  TODO: add suppernaltag abS AL the; mt thebe   bet    ideaund.
   TODO: af xpath02-01 f/      lement

ded to wrap arn cmp(selfent
    #lement instance, ), xp   ext (ent
    #"ath")nce from it name, attribun and[start:stopparam tag     y  ttdS A  attri----tructionunction on outpf xpdebugg}locallybit ASCII strinbe co
#    e@paratlementInterface} class in th it e
# eiII drik@py,
  'sIES WITHet.
# @    # @deparaeleme n
lement could oextra):
   n and[star   dividurget A str       
   FIXME: TODO: adebugg}lo
         else:
       IXME,e adds somen)ngInstruction
ment.text omenFIXME: issu impoixed  ey  ttdS A)        self impoag data.th) Ele         el             //""h se\n e names arey  ttdS A ng in("\n )p
    p am elfs h am elem e namee(tag, type(" or path. am elf am elem Root f isinsent's staeset:
          or path: a1-11-:ins umt on tment is ouparam tt the12-04 fl 
ise y  drik@py       fo1-1 e name_escope+)|\s+"
    ).r"[&<>\"\x80-\xff]+"): a1-11-
          _escope+)|\s+"
    ).e de(r'u"[&<>\"\u0080-\uffff]+"'   t_escope_map
  {bject,&":t,&amp; object,<":t,&lt; object,>":t,&gt; object'"':t,&quot; ob} t_##
# Inte_map
  {bject# "ihomas Dar"tsch)
# 2003-09-04 fject,-----------w3.org/par/1998/sch)
# 20":t,eml object,-----------w3.org//or /xhtml :t,--ml object,-----------w3.org//or /02/22-rdf-      -ns# :t,rdf object,-------schemas.emlsoap.org/wsdl/ :t,wsdl ob} t    pstanc_           re_oader(ass r       tanceTypeeset:          okens.pohe PI tar %r (with
f.path[-ot
# h     ass r.__##
#__          )p
    p am el_to rem-ot
# hpat   n=_escope: TODO: amap
-------- else:features
chnt c   ap200numtr05-01to rei4 fject    escope_to rei4 (E,emap=_escope_map)ngInstructS ALg == tag:
         )
  unction c
        retuchnt# <p>.group()r_uri
    def __st)
 maphat achntop != "/":
       _st)             return ddef __st)
 "&#%d;   ifrdachntop != "/":
   op == "/ss represents an ent returnjoin( un #""      e(tag, type(" or patp am elfpat   n.sub(escope_to rei4 _or_ur) #"Instr"T
   if isinsTypeeset:
         pstanc_           re_oader(ass r
 n
leute this softwent
# @seens umt butenstr-lement name12-04 fl   ( == utf-16 )p
    p scope_cdire.ot
# h am elem=_init_e   # @= returne   # @: TODO: aescope+chnt c   ber of    e(tag, type(""xi:is "xmlndex + 1
            except IndexEr__st)
 _ am elftt
# h am elem             if isinsAn elem(path, xpath_descendant_or_selp am el_to rem-ot
#          __st)
 e   # @ftt
# h,&",t,&amp;           __st)
 e   # @ftt
# h,<",t,&lt;           __st)
 e   # @ftt
# h,>",t,&gt;           _or_selher):
   f isins(Typeeset:,sent's staeset:)
         pstanc_           re_oader(ass r
     p scope_ext A fot
# h am elem=_init_e   # @= returne   # @: TODO: aescope+ext A string cof    e(tag, type(""xi:is "xmlndex + 1
            except IndexEr__st)
 _ am elftt
# h am elem             if isinsAn elem(path, xpath_descendant_or_selp am el_to rem-ot
#          __st)
 e   # @ftt
# h,&",t,&amp;           __st)
 e   # @ftt
# h,'",t,&apos;"): add suppnntskill         __st)
 e   # @ftt
# h,\" ,t,&quot;           __st)
 e   # @ftt
# h,<",t,&lt;           __st)
 e   # @ftt
# h,>",t,&gt;           _or_selher):
   f isins(Typeeset:,sent's staeset:)
         pstanc_           re_oader(ass r
     loxew ftory.##
# Inter  TODO: a SubElet  corata
#elf.( Note thparam tagath_,mpile(pat-09-04dntents.
is else:ch)
# 200  cla(defaultrib = aexEreturn cmp(selftory.other)element)
           her):
   ##
# Inte_.text
  ctiareturnspliactorelse,t,}",t1 factor-09-0   t#
# Interhat a##
# Inte_.te0:
       -09-0              retur-09-0   _##
# Inte_maphat a##
# Inte_.te0:
   
       -09-0              returetur-09-0   "ns%d   indexc#
# Inter          ##
# Inter[##
# Inte_.teeturn-09-0:
   
       -09-0   foeml :a            xmlns      for node i                  xmlns   ("xmlns:    re -09-0, ##
# Inte_.te0:
                 xmlns      for nont objec%s:    re( -09-0, ath_,mxmlnsill be soade.
# @paraIf the trasso<me, attribun ane n
lement co)t shouAle
# 003-odule
# 2lf._ch of Element paraIr o.
all matchind usattributes, gind usar fails, it ca    preted as ny, defext, othe names, designed to
#}gind usarsn oute f (string, xt adds somentr fails,
           l functiind us    self.texn andent.text omenF)f.texn an.      l functiind us special
# eln anill be soade.
# @paraIf the trasso<me, attribun anfines the Ellyructure  orcompl
# <'sIgo}local,ceptionusreturn rment co)t shouAle
# 003-odule
# 2lf._ch of Element paraIr o.
all matchevf a seq):
      vf a s @paraName2003 it caom WITd,cally "== "ny, def vf a sy).
  ns.pop= att Elemen #( vf a

    )tnt order,d     tement",
  :attrib
        self._chill functi vf a     self.text = tex       ext (  functi"miss"  def find(self,t shou
    el  functi"mb  self.tag are reoot()
   funcself.tag are re vf a s   #
    # @param _                inaram ,  tomeare re,  tome   for node iare reloade]+)| designed to
#()       inatio).
upptionloade]+n[stavtes</i>d in a
 node = loade]+)|are reloade]reloade] tag:
         )
 are re vf a ction c
        i   vf a s             returetu vf a s   "== "t.append(elem)
vstop] = vt(elements)

    #i   vf a   fo@para"  if not isinstance(tag, type("")):
       loade]r fl  ed_name, value=                for    loade]rL WARRAed_name, value=                for    
    {urirrctory.  This_  ti vf a= vf a

tion c=tion c,ew[1:])
                         @para=are reloade]re@para_):
 )

##
# Elementttttttttttttop == "( vf a

@paractory.  This_  )(new[1:])
             loade]rSparat.text H{urirre=  {urirr              for node ient's staeset:
              for    
    {urirrctory.  This_  ti vf a= vf a

tion c=tion c,ew[1:])
                         @para=are reloade]re@para)

##
# Elementttttttttttttop == "( vf a

@paractory.  This_  )(new[1:])
             loade]rSparat.text H{urirre=  {urirr               "xi:vf a   fo== "    except IndexErem   {urirrctory. vf a= vf a

tion c=tion c,ew[1:])
                     n c=are reloade]ren c)

##
# Elementttttttttop == "( vf a

== "/am  )  == path:
      loade]rEndt.text H{urirre=  {urirr               "xi:vf a   fo@para-ns"    except IndexErem   {urirrc -09-0, .text vf a= vf a

tion c=tion c)    except IndexErtance(tag, type("")):
       exErself):_ am elf.text"Instr"T
   i             for node iAn elem(path, xpath_descendant:
      loe first Elementttttttttop == "( vf a

c -09-0] == ", .te  )  == path:
      loade]rSparaN#
# InteD clH{urirre=  {urirr               "xi:vf a   fo== -ns"    except IndexErem   {urirrc -09-0,  vf a= vf a

tion c=tion c)    except IndexErtancop == "( vf a

   se)  == path:
      loade]rEndN#
# InteD clH{urirre=  {urirr ttrib
   nlt)

   )    exceptdex = index + 1
            except IndexEretn
menare re vf a [aram _     ]            if isins       del    except IndexEretuare reloade]+             return ddef   inaram ,  tomeare re,  t   except IndexErtance(tag, type("")):
       exEr tanceStopIr (defau
   i             for node iN#
#(path, xpath_descendant:
       tance       del xpath_descendant# loadi:vf a buffrr              forement.
    vf a [:]
set.append(node)are re                in 1
     directiare reoot(o)
   16384                    "direPath
except Importde iare reloade].feed(dire elements                              ints are re,  tomeare reloade].nt.
# @paramnamet Importde iare reloade]ome   for node i                         iare re        are re      +                forlf, pat"*"m
f    e(tag, type(""trr         
      trrinstance(other, QN))
  or path.
 
 for node iN#
#(path, xpath_delaces the given subelement.
    #
    ))
  or path.
  nlt)
)ill be soade.
# @paraIf the trram stopent is gifail text and tail attcainin on output.t(eldt, de11 fl      ] =freturnelemturn rment co)t shouAlment is given, theparaIr o.
allstring, xt adds s  attrib = attrib.copy()
    attrib.upar(ass r      loade]+)| designed to
#()     loade].feed(ot
#      pile(patoade].nt.
# @pll be soade.
# @paraIf the trram stopent is gifail     if lsatching omplygiven as ketdexch mapparam sra):
    d: s @p      nodern rment co)t shouAlment is given, theparaIr o.
allstring, es a t of Element ixt adds s  attrib t:
# <ul>
# <li>a <i>trib.copy()(Ent
    # list of sttrib.uparID(ass r      loade]+)| designed to
#()     loade].feed(ot
#      n andenloade].nt.
# @paramidue= {}
nd(elem)
       n an.

##
# Elemeelf.text = tdelf impoag ("id  self.tag = s d:ments)

    #ids[idt subelespecial
# eln anent.sill be soade.
# @paraIf the trram stopent is gifail texSam test names, parlass _El    lion",
   (ot
#   rment co)t shouAlment is given, theparaIr o.
allstring, xt adds s  attrib = attrib.copy()
    attred makeelem)| deill be Gen# Ele, in other lue, or ttly.  Use# @paraent
    #includent insf.te       return
lement could not  xt adds s  attrib = attstring, xtram eldument is given, the URIparaIr o.
allPath.findtext(self    # The <b(ent
    # am elem=_inielf.texement}
ummtag, type("loe firstdirecti #
    oot()
 
ummt @paramfot(ing in)
 
r o.tion c
    t.text omenFIXMEThe .ng in(yi     am elem       an ent returnjoin(
r o #""  ll be Gen# ictart:stopparam tag bd to
#text andbd to
#   # emu@return A liningft names, signed to
#.@para},t names, signed to
#.
r o   att be used tosigned to
#.n c} #
    # inssd/omorihomahparedtart:stopparam tagiate factory flingink #Eribute va200bd to<me, attribuparam tag  thatent)ental  dei#nloade],eturn loade]+n[ststancy.</li de-bute nammaturn
lement could not_ssing in, this
# ialized as an XML processing iny, deandli 200a200stead, ifw elf, path)

    #  asenevalui>a <     tesigned to
#:attrib
        self._chil {@link_ssing i    self.text = are redirecti #: adirecco 20ing self.tag are re on
men #: a attribupaackself.tag are re   telf.tag =    te#     empty tag are re   self.tag = trf _isewe'ag a      defad    or node in suld not_ssing in             returetu ld not_ssing inting the
# standard elf.tag are reosing inti ld not_ssing iam path What elelushuparam loade]+buffrrsructure is modio   opleveceIf the rirst subeleme@turn list of (string, xtEa):
    attrib = th.find(self, path)

            tnt.
# tance(other, QNns all ndex What     )t  f0 #" THIS
   ad    s"is functins all are re   te!=__init_" THIS
  toplevece implem"r(tag))
  or path.
      tattrib
    flush tance(other, QNetuare redirePath
except Imetuare re   te_cache.clea    except IndexEr__st)
  returnjoin(are redire #""      th
except Imetuare ree[i] = node
      s functins all are re   ttribut       Elemeference ssert(ribu)"paramnamet Importde iare re   ttribut special elnts                              ints ns all are re   ttr_st)       Elemeference ssert(rt
# "paramnamet Importde iare re   ttres a special el.text = are redirecti #ent The element to ares aception       son AssertionError If the eledirecAlment iML proceunction oning the comment ext(selall(self, given, thestringnt
# hiurn An elem  return ttrib
   dire.._childire lf.text = are redire        dire ent The elementO   ent tag.
    # eturn Ereturn A list or ites.
# @param **exlement instance.

  Agiven as ketord arguments.
# @return An elelt value no elemen   erge {@link dth.find(self, path)

            t@paracmber of subelems lf.text = are reflush )self.tag are re   telf on
menare reosing i(f subelems other, QNetuare re on
 def find(self, elee on
 //"
    # FIXME: issue wa, elee on

    # FIXME: issue wa, eleeribut s0
=None):
        for t to replace.
et.
#sption       son AssertionError If the eleor ites.
# @param **exlement e no elemennt.
#ge {@link dth.find(self, path)

            telement)

       result are reflush )self.tag are re   telf, elee on

pop )self.tag ns all are re   ttri     nod,\paramnamet Impor" ad      THances (exp0in#ge%def ot
f.path[-
ramnamet Importde iare re   ttrigxt
    def __hash__(eribut s1r(tag))
  or path.
      tatlement interfparam tag bd to
#+n[stpara)t shoudire #at elemenas ny,<b>expauctureloade].rn
lemnt(ent coontentsTntentsparam uit caom WITd,ctionbd to
#+ude.
# ny, def attrib tttrib Elxt, othe names,#signed to
#}gocaLhe
lemnt(ent co--ml Preents). HTaraeo rei4 ML procesllf._chernaltpns.popny, def A lion       sntInterface} c./>...</tand to XML.
/>...</tasigned to
#<     te designed to
#:attrib
        self._chil--ml=0,oontent    self.text = e(tag, type("")):ram sxml.     rs Elementexpau
       if isins tPath()

# TODO::
       tance tPath()

#-
ramnamet Importd"Nother 8-am **dtexpau;gink spaces designed to
#e SubEle"paramnamet Import)or node iare reloade]+)|loade]+)|expau.soaderents, (    Ele}  self.tag = sontents             returetuontents= signed to
#()       insh__(eritents= ent

PI = P  insh__(etionar= {}e, iam tmem00sache       inatli 22003s
 node = loade].Dhe matH{urirrExpa  )
 are re  return ele    loade]rSparat.text H{urirre= are re@para
:
      loade]rEndt.text H{urirre= , elee  c
        loade]rChnt c   DireH{urirre= , eleeer of    dant# lentexpaueIfctionbdffrrars, etuatpns.popn.text = e(tag, type("")):are reloade].bdffrr_res a s1
     for node ient's staeset:
             loe first Ele#gink tag-style+ext A stri {uri}lo, etuatpns.popn.text = e(tag, type("")):are reloade]. fl  ed_name, value=               are reloade].L WARRAed_name, value=               loade]rSparat.text H{urirre= are re@para_):
 
     for node ient's staeset:
             loe first Ele is "xml"  cleaparamname       loade]re is mo_un elempand XInclude  is "xml"  "itf-8"first Ele#gent insxml(ree.pars,    sef.text = are redocwith
me   for node iare rto reme= {}
ttrib
    fixult)

    #ass r        inatl # emuares ament is/omonstr, etuset},
  n.text = e(tag, type("")): or patp am elftt
# h,Instr"T
   i     node iAn elem(path, xpath_descen_or_selher):ttrib
    fixiam tribute nar        inatexpa  )qnicode ndtl # emuaiam tment is/omonstr, etuset},
  n.text = e(tag, type("")):iam t=nsh__(etionain an
   i     node iKey(path, xpath_desceniam t=nn aath
except Imetue}      _or_uri =xpath_desceniam t=n"{an biam              are retionain an   t#
#ctiare reooxult)
t#
#actory.  This funcam  ttrib
    sparacmber of subelemis_  )f._childrenixiam ctiare reooxiam          
  ctifixiam t
    def __ha, attrib){}
nd(e        knames.  Tttriblemis_   
    # ements)

    ##rned ifixiam t nar]ctiare reooxult)
    der(tag))
  or path.
   ent ins@paractory.  This) ttrib
    spara_):
 cmber of subelemis_  )f._childrenixiam ctiare reooxiam          
  ctifixiam t
    def __ha, attrib){}
nd(e    ifbelemis_  :                 ittrie fir(0,ondexelemis_  ), 2)    except IndexEr#rned ifixiam telemis_  [i]r]ctiare reooxult)
elemis_  [i+1]er(tag))
  or path.
   ent ins@paractory.  This) ttrib
    dire.._chilass r        in or path.
   ent insdire.._chreooxult)
ass r) ttrib
    element)

       result  or path.
   ent inselement)reooxiam ent facttrib
    d retur.._chilass r        inr-09-0   ass [:1 :
   
       -09-0   fo&"    except Ind adealestribements).
1to rei4 fjectexErtance(tag, type("")):
   h.
   ent insdire.._chrto rem[ass [1://"]             if isinsKey(path, xpath_descen")):ram sxml.     rs Elementexpau
       i:
       tanceexpau.e)

#-
ramnamet Importdortd"ements).
1to rey
f.: ls). %dyworlumn %d   
ramnamet Importdortdftt
# hare reloade].(pathLs).N @par,ath
except Importde iare reloade].(pathCrlumnN @par@paramnamet Importde i            "xi -09-0   fo<"ucturass [:9    fo<!DOCTYPE"ag, type("")):are redocwith
me #: a Suide   docwith
  cla(defau           "xiare redocwith
_cache.clea    except Ind#nloade docwith
ment

death
except Imetu -09-0   fo>"ag, type("")):
   h.
   docwith
me   for node i result  or pa
cept IndexEr__st)
  return retp-ot
#                   el ssingInstruct         or pa
cept IndexErh.
   docwith.op == "/ss representsscenistardex What docwith                   > 2    except IndexEr_ith
me What docwith[1]     th
except Imetu_ith
m foPUBLIC"ucturn
m f4                 ints nicode_ith, pubidywsystn
menare redocwithal elnts           etu_ith
m foSYSTEM"ucturn
m f3                 ints nicode_ith, systn
menare redocwithal elnts           inrubid
me   for node i result                      ints  or pa
cept IndexErt Imetu ubid:al elnts           inrubid
merubid[1://"g, type("")):
   h.
  docwithuples

pubidywsystn
[1://")g, type("")):
   h.
   docwith
me   fot to replace.
H{urirs   docwith
  cla(defaurtionError If the eleiam cDocwith
m **exlement instanrubid
Publicnt to rRAehe text content systn
mSystn
mt to rRAehe ttrib
   docwithu._chilples

pubidywsystn
)ag, type("loe fm path What eleeedsedirecceptionloade].rionError If the eledirecEam elduIr o.

    # Reseed(._childire lf.text = are reloade].soade(
r o #0ram path What elemeishupaseedt isdirecceptionloade].rionError If tstring, xtra):
   param tagiath.find(self, path)

            tnt.
# tance(other, QNare reloade].soade("",t1 nateAsserter of    dantn andenh.
   ent insnt.
# @paramname